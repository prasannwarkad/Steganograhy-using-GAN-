# -*- coding: utf-8 -*-
"""Top-level package for SteganoGAN."""

__author__ = """PES MCOE"""
__email__ = 'hbagul16@gmail.com'
__version__ = '0.1.0-dev'

from steganogan.models import SteganoGAN

__all__ = ('SteganoGAN', )
